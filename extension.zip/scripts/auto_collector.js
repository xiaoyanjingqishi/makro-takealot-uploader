// =======================================================
// Takealot 智能自动筛选与翻页采集引擎 (Makro Auto Collector - 独立命名空间版)
// =======================================================

(function () {
  'use strict';

  // 仅在 Takealot 列表页/类目页/搜索页中运行，详情页不注入
  function isPLP() {
    return !/PLID\d+/i.test(window.location.href);
  }

  if (!isPLP()) return;

  // 运行状态与配置模型
  const state = {
    running: false,
    paused: false,
    minPrice: '',
    maxPrice: '',
    minReviews: '',
    maxReviews: '',
    minRating: '4.0',
    maxCollectItems: 50,
    maxScanPages: 10,
    filterSponsored: true,
    filterRestricted: true,
    filterAlreadyCollected: true,
    autoList: false,

    // 运行统计
    scannedCount: 0,
    collectedCount: 0,
    skippedCount: 0,
    currentPage: 1,
    processedPlids: new Set()
  };

  let panelEl = null;
  let capsuleEl = null;
  let logBoxEl = null;

  // 1. 初始化 DOM 界面 (全面采用专属 makro- 前缀)
  function initUI() {
    if (document.getElementById('makro-auto-capsule')) return;

    // A. 悬浮胶囊入口按钮 (科技蓝，位于 bottom: 140px，避免与跟价胶囊 bottom: 85px 物理重叠)
    capsuleEl = document.createElement('div');
    capsuleEl.id = 'makro-auto-capsule';
    capsuleEl.innerHTML = `
      <span class="makro-capsule-icon">📦</span>
      <span>Makro批量采集</span>
      <span class="makro-capsule-badge" id="makroCapsuleCount" style="display:none;">0</span>
    `;
    capsuleEl.title = '打开 Makro 自动筛选与批量翻页采集面板';
    capsuleEl.addEventListener('click', () => {
      togglePanel(true);
    });
    document.body.appendChild(capsuleEl);

    // B. 主控制面板
    panelEl = document.createElement('div');
    panelEl.id = 'makro-auto-panel';
    panelEl.style.display = 'none';
    panelEl.innerHTML = `
      <div class="makro-auto-header" id="makroAutoHeader">
        <div class="makro-auto-title">
          <span>📦</span>
          <span>Makro 自动筛选与批量采集</span>
        </div>
        <div class="makro-auto-controls">
          <button type="button" class="makro-auto-btn-icon" id="makroAutoMinBtn" title="最小化">−</button>
          <button type="button" class="makro-auto-btn-icon" id="makroAutoCloseBtn" title="关闭">✕</button>
        </div>
      </div>

      <div class="makro-auto-body">
        <!-- 筛选预设条件 -->
        <div class="makro-auto-section">
          <div class="makro-auto-sec-title">
            <span>🎯 过滤与筛选条件</span>
            <span style="font-size:10px; color:#a0aec0; font-weight:normal;">留空表示不限</span>
          </div>

          <!-- 价格区间 -->
          <div class="makro-auto-row">
            <span class="makro-auto-label">价格区间:</span>
            <div class="makro-auto-input-group">
              <input type="number" id="makroMinPrice" class="makro-auto-input makro-auto-input-short" placeholder="最低 R" min="0">
              <span class="makro-auto-sep">~</span>
              <input type="number" id="makroMaxPrice" class="makro-auto-input makro-auto-input-short" placeholder="最高 R" min="0">
            </div>
          </div>

          <!-- 评论数量 -->
          <div class="makro-auto-row">
            <span class="makro-auto-label">评论数量:</span>
            <div class="makro-auto-input-group">
              <input type="number" id="makroMinReviews" class="makro-auto-input makro-auto-input-short" placeholder="最少条数" min="0">
              <span class="makro-auto-sep">~</span>
              <input type="number" id="makroMaxReviews" class="makro-auto-input makro-auto-input-short" placeholder="最多条数" min="0">
            </div>
          </div>

          <!-- 星级要求 -->
          <div class="makro-auto-row">
            <span class="makro-auto-label">最低星级:</span>
            <div class="makro-auto-input-group">
              <input type="number" id="makroMinRating" class="makro-auto-input makro-auto-input-short" placeholder="如 4.0" step="0.1" min="0" max="5" value="4.0">
              <span style="font-size:11px; color:#718096; margin-left:6px;">⭐ 星以上</span>
            </div>
          </div>

          <!-- 采集上限 & 翻页上限 -->
          <div class="makro-auto-row">
            <span class="makro-auto-label">采集目标:</span>
            <div class="makro-auto-input-group">
              <input type="number" id="makroMaxCollect" class="makro-auto-input makro-auto-input-short" value="50" min="1" max="1000">
              <span style="font-size:11px; color:#718096; margin-left:4px;">件</span>
              <span class="makro-auto-label" style="min-width:45px; text-align:right; margin-left:6px;">最多翻:</span>
              <input type="number" id="makroMaxPages" class="makro-auto-input makro-auto-input-short" value="10" min="1" max="50">
              <span style="font-size:11px; color:#718096; margin-left:4px;">页</span>
            </div>
          </div>

          <!-- 安全过滤开关 -->
          <div class="makro-auto-checkbox-row">
            <input type="checkbox" id="makroFilterAlreadyCollected" checked>
            <label for="makroFilterAlreadyCollected">📦 自动跳过已在选品箱中的商品 (取消则重新采集覆盖)</label>
          </div>

          <div class="makro-auto-checkbox-row">
            <input type="checkbox" id="makroFilterRestricted" checked>
            <label for="makroFilterRestricted">🛡️ 智能排除受限/独立品牌与选品黑名单 (假发/液体/3C等)</label>
          </div>

          <div class="makro-auto-checkbox-row">
            <input type="checkbox" id="makroFilterSponsored" checked>
            <label for="makroFilterSponsored">🚫 排除 Sponsored 赞助广告品</label>
          </div>

          <div class="makro-auto-checkbox-row" style="display:none;">
            <input type="checkbox" id="makroAutoList">
            <label for="makroAutoList">⚡ 采集后立即直上到店铺</label>
          </div>
        </div>

        <!-- 操作按钮 -->
        <div class="makro-auto-actions">
          <button type="button" class="makro-auto-btn makro-auto-btn-primary" id="makroAutoStartBtn">
            <span>🚀</span> <span>开始自动采集</span>
          </button>
          <button type="button" class="makro-auto-btn makro-auto-btn-secondary" id="makroAutoPauseBtn" style="display:none;">
            <span>⏸</span> <span>暂停</span>
          </button>
          <button type="button" class="makro-auto-btn makro-auto-btn-danger" id="makroAutoStopBtn" style="display:none;">
            <span>⏹</span> <span>停止</span>
          </button>
        </div>

        <!-- 进度与统计 -->
        <div class="makro-auto-section" style="margin-top:10px;">
          <div class="makro-auto-sec-title">
            <span>📊 采集与过滤进度</span>
            <span id="makroRunStatusText" style="font-size:11px; font-weight:normal; color:#718096;">就绪</span>
          </div>

          <div class="makro-auto-progress-bar">
            <div class="makro-auto-progress-fill" id="makroProgressFill"></div>
          </div>

          <div class="makro-auto-stats-grid">
            <div class="makro-auto-stat-box success">
              <div class="makro-auto-stat-num" id="makroStatSuccess">0</div>
              <div class="makro-auto-stat-label">符合入库</div>
            </div>
            <div class="makro-auto-stat-box filter">
              <div class="makro-auto-stat-num" id="makroStatSkip">0</div>
              <div class="makro-auto-stat-label">条件过滤</div>
            </div>
            <div class="makro-auto-stat-box page">
              <div class="makro-auto-stat-num" id="makroStatPage">1</div>
              <div class="makro-auto-stat-label">当前页/批次</div>
            </div>
          </div>
        </div>

        <!-- 实时日志 -->
        <div class="makro-auto-section" style="margin-bottom:0;">
          <div class="makro-auto-sec-title">
            <span>📜 实时运行日志</span>
            <a href="javascript:void(0)" id="makroClearLogBtn" style="font-size:10px; color:#2563eb; text-decoration:none;">清空</a>
          </div>
          <div class="makro-auto-log-box" id="makroLogBox">
            <div class="makro-auto-log-line info">[系统就绪] 请在上方预设筛选条件，点击「开始自动采集」。</div>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(panelEl);
    logBoxEl = document.getElementById('makroLogBox');

    // 绑定事件
    bindUIEvents();

    // 恢复历史配置
    loadSavedSettings();
  }

  function togglePanel(show) {
    if (!panelEl) return;
    if (show) {
      panelEl.style.display = 'flex';
      capsuleEl.style.display = 'none';
    } else {
      panelEl.style.display = 'none';
      capsuleEl.style.display = 'flex';
    }
  }

  // 绑定界面交互事件
  function bindUIEvents() {
    // 最小化 / 关闭
    document.getElementById('makroAutoCloseBtn').addEventListener('click', () => togglePanel(false));
    document.getElementById('makroAutoMinBtn').addEventListener('click', () => {
      panelEl.classList.toggle('minimized');
    });

    // 拖拽面板头部
    makeDraggable(document.getElementById('makroAutoHeader'), panelEl);

    // 清空日志
    document.getElementById('makroClearLogBtn').addEventListener('click', () => {
      if (logBoxEl) logBoxEl.innerHTML = '';
    });

    // 实时保存配置
    const inputs = ['makroMinPrice', 'makroMaxPrice', 'makroMinReviews', 'makroMaxReviews', 'makroMinRating', 'makroMaxCollect', 'makroMaxPages', 'makroFilterAlreadyCollected', 'makroFilterRestricted', 'makroFilterSponsored', 'makroAutoList'];
    inputs.forEach(id => {
      const el = document.getElementById(id);
      if (el) {
        el.addEventListener('change', saveSettingsFromUI);
      }
    });

    // 开始采集
    document.getElementById('makroAutoStartBtn').addEventListener('click', startAutoCollect);

    // 暂停/恢复
    document.getElementById('makroAutoPauseBtn').addEventListener('click', () => {
      if (!state.running) return;
      state.paused = !state.paused;
      const pauseBtn = document.getElementById('makroAutoPauseBtn');
      if (state.paused) {
        pauseBtn.innerHTML = '<span>▶</span> <span>继续</span>';
        updateStatusText('已暂停');
        addLog('⏸ 自动化采集已暂停', 'warn');
      } else {
        pauseBtn.innerHTML = '<span>⏸</span> <span>暂停</span>';
        updateStatusText('正在运行...');
        addLog('▶ 自动化采集已恢复执行', 'info');
      }
    });

    // 停止采集
    document.getElementById('makroAutoStopBtn').addEventListener('click', stopAutoCollect);
  }

  // 从 UI 读取配置并保存
  function saveSettingsFromUI() {
    state.minPrice = document.getElementById('makroMinPrice').value.trim();
    state.maxPrice = document.getElementById('makroMaxPrice').value.trim();
    state.minReviews = document.getElementById('makroMinReviews').value.trim();
    state.maxReviews = document.getElementById('makroMaxReviews').value.trim();
    state.minRating = document.getElementById('makroMinRating').value.trim();
    state.maxCollectItems = parseInt(document.getElementById('makroMaxCollect').value, 10) || 50;
    state.maxScanPages = parseInt(document.getElementById('makroMaxPages').value, 10) || 10;
    state.filterAlreadyCollected = document.getElementById('makroFilterAlreadyCollected') ? document.getElementById('makroFilterAlreadyCollected').checked : true;
    state.filterRestricted = document.getElementById('makroFilterRestricted').checked;
    state.filterSponsored = document.getElementById('makroFilterSponsored').checked;
    state.autoList = document.getElementById('makroAutoList') ? document.getElementById('makroAutoList').checked : false;

    const savedData = {
      makro_auto_collector: {
        minPrice: state.minPrice,
        maxPrice: state.maxPrice,
        minReviews: state.minReviews,
        maxReviews: state.maxReviews,
        minRating: state.minRating,
        maxCollectItems: state.maxCollectItems,
        maxScanPages: state.maxScanPages,
        filterAlreadyCollected: state.filterAlreadyCollected,
        filterRestricted: state.filterRestricted,
        filterSponsored: state.filterSponsored,
        autoList: state.autoList
      }
    };
    chrome.storage.local.set(savedData);
  }

  // 加载已保存配置 (优先从专属存储加载，兼容历史键)
  function loadSavedSettings() {
    chrome.storage.local.get(['makro_auto_collector', 'autoCollector', 'autoList'], (res) => {
      const c = res?.makro_auto_collector || res?.autoCollector || {};
      if (c.minPrice !== undefined && document.getElementById('makroMinPrice')) {
        document.getElementById('makroMinPrice').value = c.minPrice;
        state.minPrice = c.minPrice;
      }
      if (c.maxPrice !== undefined && document.getElementById('makroMaxPrice')) {
        document.getElementById('makroMaxPrice').value = c.maxPrice;
        state.maxPrice = c.maxPrice;
      }
      if (c.minReviews !== undefined && document.getElementById('makroMinReviews')) {
        document.getElementById('makroMinReviews').value = c.minReviews;
        state.minReviews = c.minReviews;
      }
      if (c.maxReviews !== undefined && document.getElementById('makroMaxReviews')) {
        document.getElementById('makroMaxReviews').value = c.maxReviews;
        state.maxReviews = c.maxReviews;
      }
      if (c.minRating !== undefined && document.getElementById('makroMinRating')) {
        document.getElementById('makroMinRating').value = c.minRating;
        state.minRating = c.minRating;
      }
      if (c.maxCollectItems !== undefined && document.getElementById('makroMaxCollect')) {
        document.getElementById('makroMaxCollect').value = c.maxCollectItems;
        state.maxCollectItems = c.maxCollectItems;
      }
      if (c.maxScanPages !== undefined && document.getElementById('makroMaxPages')) {
        document.getElementById('makroMaxPages').value = c.maxScanPages;
        state.maxScanPages = c.maxScanPages;
      }
      if (c.filterAlreadyCollected !== undefined && document.getElementById('makroFilterAlreadyCollected')) {
        document.getElementById('makroFilterAlreadyCollected').checked = !!c.filterAlreadyCollected;
        state.filterAlreadyCollected = !!c.filterAlreadyCollected;
      }
      if (c.filterRestricted !== undefined && document.getElementById('makroFilterRestricted')) {
        document.getElementById('makroFilterRestricted').checked = !!c.filterRestricted;
        state.filterRestricted = !!c.filterRestricted;
      }
      if (c.filterSponsored !== undefined && document.getElementById('makroFilterSponsored')) {
        document.getElementById('makroFilterSponsored').checked = !!c.filterSponsored;
        state.filterSponsored = !!c.filterSponsored;
      }
      if (c.autoList !== undefined && document.getElementById('makroAutoList')) {
        document.getElementById('makroAutoList').checked = !!c.autoList;
        state.autoList = !!c.autoList;
      }
    });
  }

  // 日志记录与更新
  function addLog(msg, type = 'info') {
    if (!logBoxEl) return;
    const timeStr = new Date().toTimeString().slice(0, 8);
    const line = document.createElement('div');
    line.className = `makro-auto-log-line ${type}`;
    line.textContent = `[${timeStr}] ${msg}`;
    logBoxEl.appendChild(line);
    logBoxEl.scrollTop = logBoxEl.scrollHeight;
  }

  function updateStatusText(txt) {
    const el = document.getElementById('makroRunStatusText');
    if (el) el.textContent = txt;
  }

  function updateDashboard() {
    const sSucc = document.getElementById('makroStatSuccess');
    const sSkip = document.getElementById('makroStatSkip');
    const sPage = document.getElementById('makroStatPage');
    const pFill = document.getElementById('makroProgressFill');
    const capCount = document.getElementById('makroCapsuleCount');

    if (sSucc) sSucc.textContent = state.collectedCount;
    if (sSkip) sSkip.textContent = state.skippedCount;
    if (sPage) sPage.textContent = state.currentPage;

    const pct = Math.min(100, Math.round((state.collectedCount / Math.max(1, state.maxCollectItems)) * 100));
    if (pFill) pFill.style.width = `${pct}%`;

    if (capCount) {
      if (state.collectedCount > 0) {
        capCount.style.display = 'inline-block';
        capCount.textContent = state.collectedCount;
      } else {
        capCount.style.display = 'none';
      }
    }
  }

  // 2. 单个卡片深度数据提取器
  function parseProductCard(card) {
    // 提取 PLID
    let plid = card.id;
    if (!plid || !/^\d+$/.test(plid)) {
      const link = card.querySelector('a[href*="/PLID"], a[href*="PLID"]');
      const href = link ? (link.getAttribute('href') || '') : '';
      const m = href.match(/PLID(\d+)/i);
      if (m) plid = m[1];
    }
    if (!plid || !/^\d+$/.test(plid)) return null;

    // 提取标题 (避免 Takealot 的 "Go to product details" 占位链接干扰)
    let title = '';
    const h4 = card.querySelector('h4, [class*="product-title"], [class*="title-"]');
    if (h4) {
      title = h4.innerText.trim();
    } else {
      const titleLinks = card.querySelectorAll('a[title]');
      for (const tl of titleLinks) {
        const tVal = (tl.getAttribute('title') || '').trim();
        if (tVal && tVal.toLowerCase() !== 'go to product details') {
          title = tVal;
          break;
        }
      }
    }

    // 提取价格 (ZAR)
    let price = null;
    let priceText = '';
    const priceEls = card.querySelectorAll('[class*="price"], [class*="currency"]');
    for (const el of priceEls) {
      const txt = el.innerText || '';
      const m = txt.match(/R\s*([\d,]+(?:\.\d+)?)/i);
      if (m) {
        priceText = m[0];
        price = parseFloat(m[1].replace(/,/g, ''));
        break;
      }
    }

    // 提取评论星级与数量
    let rating = 0;
    let reviewCount = 0;
    const ratingEls = card.querySelectorAll('[class*="rating"], [class*="review"], [aria-label*="star"], [class*="star"]');
    for (const el of ratingEls) {
      const txt = el.innerText || el.getAttribute('aria-label') || '';
      const m = txt.match(/([\d\.]+)\s*\(\s*([\d,]+)\s*\)/);
      if (m) {
        rating = parseFloat(m[1]);
        reviewCount = parseInt(m[2].replace(/,/g, ''), 10);
        break;
      }
    }
    if (rating === 0) {
      const starEl = card.querySelector('[class*="rating-star"], [class*="rating-score"], [aria-label*="star"]');
      if (starEl) {
        const m = (starEl.innerText || starEl.getAttribute('aria-label') || '').match(/([\d\.]+)/);
        if (m) rating = parseFloat(m[1]);
      }
      const countEl = card.querySelector('[class*="rating-count"], [class*="reviews-count"]');
      if (countEl) {
        const m = countEl.innerText.match(/([\d,]+)/);
        if (m) reviewCount = parseInt(m[1].replace(/,/g, ''), 10);
      }
    }

    // 检测 Sponsored 赞助广告
    const isSponsored = /sponsored|赞助/i.test(card.innerText);

    // 检测受限品牌、独立品牌与选品黑名单
    let hitBrand = null;
    const brandChecker = window.MakroBrandChecker || window.TkBrandChecker;
    if (brandChecker) {
      hitBrand = brandChecker.detectInScope(card);
      if (!hitBrand && title && title.toLowerCase() !== 'go to product details') {
        hitBrand = brandChecker.checkTitle(title);
      }
    }

    return {
      card,
      plid,
      title,
      price,
      priceText,
      rating,
      reviewCount,
      isSponsored,
      hitBrand
    };
  }

  // 3. 过滤规则核验
  function evaluateCard(data) {
    const { price, rating, reviewCount, isSponsored, hitBrand, isAlreadyCollected, collectedCount } = data;

    // 0. 已入库重复商品过滤 (勾选跳过时直接拦截)
    if (state.filterAlreadyCollected && isAlreadyCollected) {
      return { pass: false, reason: `已在选品箱 (${collectedCount || 1}变体)`, type: 'skip' };
    }

    // A. 品牌与黑名单风控拦截
    if (state.filterRestricted && hitBrand) {
      return { pass: false, reason: hitBrand, type: 'danger' };
    }

    // B. 赞助广告拦截
    if (state.filterSponsored && isSponsored) {
      return { pass: false, reason: '赞助广告', type: 'skip' };
    }

    // C. 价格区间检验
    if (state.minPrice !== '' && !isNaN(parseFloat(state.minPrice))) {
      const minP = parseFloat(state.minPrice);
      if (price === null || price < minP) {
        return { pass: false, reason: `价格 R${price || 0} < R${minP}`, type: 'skip' };
      }
    }
    if (state.maxPrice !== '' && !isNaN(parseFloat(state.maxPrice))) {
      const maxP = parseFloat(state.maxPrice);
      if (price === null || price > maxP) {
        return { pass: false, reason: `价格 R${price || 0} > R${maxP}`, type: 'skip' };
      }
    }

    // D. 评论数量要求
    if (state.minReviews !== '' && !isNaN(parseInt(state.minReviews, 10))) {
      const minR = parseInt(state.minReviews, 10);
      if (reviewCount < minR) {
        return { pass: false, reason: `评论 ${reviewCount} < ${minR}`, type: 'skip' };
      }
    }
    if (state.maxReviews !== '' && !isNaN(parseInt(state.maxReviews, 10))) {
      const maxR = parseInt(state.maxReviews, 10);
      if (reviewCount > maxR) {
        return { pass: false, reason: `评论 ${reviewCount} > ${maxR}`, type: 'skip' };
      }
    }

    // E. 评论星级要求
    if (state.minRating !== '' && !isNaN(parseFloat(state.minRating))) {
      const minRat = parseFloat(state.minRating);
      if (rating < minRat) {
        return { pass: false, reason: `评分 ${rating}⭐ < ${minRat}⭐`, type: 'skip' };
      }
    }

    return { pass: true, reason: '符合条件', type: 'ok' };
  }

  // 4. 卡片状态打标装饰 (独立 Makro 专属类名)
  function markCardBadge(card, text, type) {
    if (!card) return;
    card.classList.remove('makro-card-matched', 'makro-card-skipped', 'makro-card-restricted');
    if (type === 'ok') card.classList.add('makro-card-matched');
    else if (type === 'danger') card.classList.add('makro-card-restricted');
    else card.classList.add('makro-card-skipped');

    let badge = card.querySelector('.makro-card-status-badge');
    if (!badge) {
      badge = document.createElement('div');
      badge.className = `makro-card-status-badge ${type}`;
      card.appendChild(badge);
    } else {
      badge.className = `makro-card-status-badge ${type}`;
    }
    badge.textContent = text;
  }

  // 批量检查 PLID 列表是否已在选品箱中
  function checkPlidsExistence(plids) {
    return new Promise((resolve) => {
      if (!plids || !plids.length) return resolve({});
      chrome.runtime.sendMessage({
        action: 'CHECK_PLIDS_EXISTENCE',
        plids: plids
      }, (res) => {
        if (res && res.success && res.exists) {
          resolve(res.exists);
        } else {
          resolve({});
        }
      });
    });
  }

  // 5. 自动采集执行主调度器
  async function startAutoCollect() {
    saveSettingsFromUI();

    state.running = true;
    state.paused = false;
    state.scannedCount = 0;
    state.collectedCount = 0;
    state.skippedCount = 0;
    state.currentPage = 1;
    state.processedPlids.clear();

    document.getElementById('makroAutoStartBtn').style.display = 'none';
    document.getElementById('makroAutoPauseBtn').style.display = 'inline-flex';
    document.getElementById('makroAutoStopBtn').style.display = 'inline-flex';

    updateStatusText('正在运行...');
    updateDashboard();

    addLog(`🚀 启动 Makro 自动采集: 价格[${state.minPrice || '不限'}~${state.maxPrice || '不限'}] 评论>=${state.minReviews || '不限'} 评分>=${state.minRating || '不限'}⭐`, 'info');
    addLog(`🎯 目标采集上限: ${state.maxCollectItems} 件, 最大翻页数: ${state.maxScanPages} 页, 跳过已采商品: ${state.filterAlreadyCollected ? '开启' : '关闭(覆盖)'}`, 'info');

    try {
      await runCollectionLoop();
    } catch (err) {
      addLog(`❌ 采集执行异常: ${err.message}`, 'error');
    } finally {
      stopAutoCollect();
    }
  }

  // 采集主循环（逐批扫描 + 自动翻页/Load More）
  async function runCollectionLoop() {
    while (state.running) {
      // 暂停等待
      while (state.paused && state.running) {
        await sleep(500);
      }
      if (!state.running) break;

      addLog(`🔍 开始扫描第 ${state.currentPage} 页/批次商品...`, 'info');

      // 提取当前 DOM 中所有商品卡片
      const cards = Array.from(document.querySelectorAll('article.product-card, article[id], [data-ref="product-card"], .product-card'));
      const unscannedCards = [];

      for (const card of cards) {
        const parsed = parseProductCard(card);
        if (parsed && !state.processedPlids.has(parsed.plid)) {
          unscannedCards.push(parsed);
          state.processedPlids.add(parsed.plid);
        }
      }

      addLog(`本批次发现 ${unscannedCards.length} 个新商品 (总计加载 ${cards.length} 件)`, 'info');

      // 批量预检当前批次新商品的选品箱入库状态
      const plidsToCheck = unscannedCards.map(c => c.plid);
      if (plidsToCheck.length > 0) {
        try {
          const existenceMap = await checkPlidsExistence(plidsToCheck);
          for (const item of unscannedCards) {
            const info = existenceMap[item.plid] || existenceMap['PLID' + item.plid] || null;
            if (info && info.collected) {
              item.isAlreadyCollected = true;
              item.collectedCount = info.count || 1;
            }
          }
        } catch (e) {
          console.warn('[MakroAutoCollector] 批量存在性检查失败:', e);
        }
      }

      // 逐个比对并采集
      for (const item of unscannedCards) {
        if (!state.running) break;
        while (state.paused && state.running) {
          await sleep(500);
        }
        if (!state.running) break;

        state.scannedCount++;
        const check = evaluateCard(item);

        if (!check.pass) {
          state.skippedCount++;
          markCardBadge(item.card, `✗ ${check.reason}`, check.type);
          // 如果是受限品牌或重要广告或已在选品箱跳过，记录日志
          if (check.type === 'danger') {
            addLog(`[PLID ${item.plid}] 🛡️ 排除: ${check.reason}`, 'warn');
          } else if (item.isAlreadyCollected) {
            addLog(`[PLID ${item.plid}] 📦 跳过: 已在选品箱 (${item.collectedCount || 1}变体)`, 'info');
          }
          updateDashboard();
          continue;
        }

        // 符合条件 -> 采集入库 (识别是首次入库还是重新采集覆盖)
        const isReScrape = !!item.isAlreadyCollected;
        markCardBadge(item.card, isReScrape ? '⏳ 正在重采覆盖...' : '⏳ 正在采集入库...', 'ok');
        addLog(`[PLID ${item.plid}] 🎯 ${isReScrape ? '重新采集覆盖' : '命中目标'} (R${item.price || 0}, ${item.rating || 0}⭐, ${item.reviewCount || 0}评) -> 入库中...`, 'info');

        const success = await scrapeSingleProduct(item);
        if (success) {
          state.collectedCount++;
          const succBadge = isReScrape ? '✓ 重采已覆盖' : '✓ 符合已入库';
          markCardBadge(item.card, succBadge, 'ok');
          addLog(`[PLID ${item.plid}] ${succBadge}！(当前已达成 ${state.collectedCount}/${state.maxCollectItems})`, 'success');
        } else {
          markCardBadge(item.card, '❌ 入库失败', 'skip');
        }

        updateDashboard();

        // 检查是否已达到目标上限
        if (state.collectedCount >= state.maxCollectItems) {
          addLog(`🎉 已达目标采集数量 (${state.collectedCount} 件)，采集圆满完成！`, 'success');
          updateStatusText('采集已达成');
          return;
        }

        // 采集间隔防频控
        await sleep(700);
      }

      if (!state.running) break;

      // 检查是否已达最大翻页数
      if (state.currentPage >= state.maxScanPages) {
        addLog(`🏁 已达最大翻页批次 (${state.maxScanPages} 页)，采集结束。`, 'info');
        updateStatusText('已达最大页数');
        return;
      }

      // 尝试自动加载下一页 / Load More
      addLog(`⏳ 准备加载下一批商品 (Load More / 自动翻页)...`, 'info');
      const loadedMore = await triggerNextPage();
      if (!loadedMore) {
        addLog(`🏁 页面已无更多商品或翻页结束。`, 'info');
        updateStatusText('无更多商品');
        return;
      }

      state.currentPage++;
      updateDashboard();
      // 等待新商品在 DOM 中渲染
      await sleep(2000);
    }
  }

  // 触发翻页或点击 Load More
  async function triggerNextPage() {
    // 1. 滚动到页面底部以激活懒加载
    window.scrollTo({
      top: document.body.scrollHeight - 500,
      behavior: 'smooth'
    });
    await sleep(800);

    // 2. 优先查找 "Load More" 按钮
    const allBtns = Array.from(document.querySelectorAll('button, a'));
    const loadMoreBtn = allBtns.find(b => {
      const txt = b.innerText.trim().toLowerCase();
      return /load more|加载更多/i.test(txt);
    });

    if (loadMoreBtn && isElementVisible(loadMoreBtn)) {
      const beforeCount = document.querySelectorAll('article.product-card, article[id], [data-ref="product-card"], .product-card').length;
      loadMoreBtn.click();
      addLog('🖱️ 已点击「Load More」加载更多商品...', 'info');

      // 轮询等待新卡片渲染
      for (let i = 0; i < 12; i++) {
        await sleep(500);
        const curCount = document.querySelectorAll('article.product-card, article[id], [data-ref="product-card"], .product-card').length;
        if (curCount > beforeCount) {
          addLog(`✨ 成功加载新商品 (卡片总数增至 ${curCount})`, 'success');
          return true;
        }
      }
      return false;
    }

    // 3. 若无 Load More，检测常规下一页链接 (Next / › / Pagination)
    const nextLink = allBtns.find(b => {
      const txt = b.innerText.trim().toLowerCase();
      const aria = (b.getAttribute('aria-label') || '').toLowerCase();
      return /next|下一页|›|»/i.test(txt) || /next/i.test(aria);
    });

    if (nextLink && isElementVisible(nextLink)) {
      addLog('🖱️ 正在点击下一页按钮...', 'info');
      nextLink.click();
      await sleep(2500);
      return true;
    }

    // 4. 若为标准 page 参数 URL
    const url = new URL(window.location.href);
    const curPageParam = parseInt(url.searchParams.get('page') || '1', 10);
    url.searchParams.set('page', curPageParam + 1);
    addLog(`🌐 跳转至第 ${curPageParam + 1} 页: ${url.href}`, 'info');
    window.location.href = url.href;
    return false;
  }

  function isElementVisible(el) {
    return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  }

  // 单品采集推送至后端
  function scrapeSingleProduct(item) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({
        action: 'COLLECT_PLID',
        data: {
          plid: item.plid,
          title: item.title,
          price: item.price,
          is_restricted: item.hitBrand ? 1 : 0,
          restricted_brand: item.hitBrand || '',
          auto_list: state.autoList
        }
      }, (res) => {
        if (res && (res.ok || res.success)) {
          resolve(true);
        } else {
          addLog(`[PLID ${item.plid}] 采集失败: ${res?.message || res?.error || '网络异常'}`, 'error');
          resolve(false);
        }
      });
    });
  }

  // 停止采集
  function stopAutoCollect() {
    state.running = false;
    state.paused = false;

    const startBtn = document.getElementById('makroAutoStartBtn');
    const pauseBtn = document.getElementById('makroAutoPauseBtn');
    const stopBtn = document.getElementById('makroAutoStopBtn');

    if (startBtn) startBtn.style.display = 'inline-flex';
    if (pauseBtn) pauseBtn.style.display = 'none';
    if (stopBtn) stopBtn.style.display = 'none';

    updateStatusText('已停止');
    addLog(`⏹ 自动采集已终止。本次共扫描 ${state.scannedCount} 件，命中入库 ${state.collectedCount} 件，过滤跳过 ${state.skippedCount} 件。`, 'info');
  }

  function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
  }

  // 支持拖拽面板
  function makeDraggable(handle, target) {
    let pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
    handle.onmousedown = dragMouseDown;

    function dragMouseDown(e) {
      if (e.target.tagName === 'BUTTON') return;
      e.preventDefault();
      pos3 = e.clientX;
      pos4 = e.clientY;
      document.onmouseup = closeDragElement;
      document.onmousemove = elementDrag;
    }

    function elementDrag(e) {
      e.preventDefault();
      pos1 = pos3 - e.clientX;
      pos2 = pos4 - e.clientY;
      pos3 = e.clientX;
      pos4 = e.clientY;
      target.style.top = (target.offsetTop - pos2) + "px";
      target.style.left = (target.offsetLeft - pos1) + "px";
      target.style.bottom = 'auto';
      target.style.right = 'auto';
    }

    function closeDragElement() {
      document.onmouseup = null;
      document.onmousemove = null;
    }
  }

  // 监听来自 Popup 的指令 (支持专属与通用两种 Action)
  chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req.action === 'OPEN_MAKRO_AUTO_COLLECTOR' || req.action === 'OPEN_AUTO_COLLECTOR') {
      initUI();
      togglePanel(true);
      sendResponse({ ok: true });
      return true;
    }
    if (req.action === 'START_MAKRO_AUTO_COLLECT' || req.action === 'START_AUTO_COLLECT') {
      initUI();
      togglePanel(true);
      if (!state.running) {
        startAutoCollect();
      }
      sendResponse({ ok: true });
      return true;
    }
    if (req.action === 'STOP_MAKRO_AUTO_COLLECT' || req.action === 'STOP_AUTO_COLLECT') {
      stopAutoCollect();
      sendResponse({ ok: true });
      return true;
    }
    if (req.action === 'GET_MAKRO_AUTO_COLLECT_STATE' || req.action === 'GET_AUTO_COLLECT_STATE') {
      sendResponse({ ok: true, state });
      return true;
    }
  });

  // 页面加载完成后自动初始化入口胶囊
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initUI);
  } else {
    setTimeout(initUI, 400);
  }

})();
